import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'SSIM – Siva Sivani Institute of Management | Hyderabad',
  description: 'Premier PGDM programs with triple specialisation, industry-integrated curriculum, and a 30,000+ strong global alumni network at the heart of India\'s fastest-growing business hub.',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
