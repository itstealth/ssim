# SSIM Website – Next.js + Tailwind CSS

This is the SSIM (Siva Sivani Institute of Management) website converted from plain HTML/CSS to **Next.js 14** with **Tailwind CSS**.

## Getting Started

### 1. Install dependencies

```bash
npm install
```

### 2. Run the development server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### 3. Build for production

```bash
npm run build
npm run start
```

---

## Project Structure

```
ssim-nextjs/
├── app/
│   ├── globals.css        # Global styles (fonts, keyframes, nav/dropdown CSS)
│   ├── layout.tsx         # Root layout with metadata
│   └── page.tsx           # Main page assembling all sections
├── components/
│   ├── Ticker.tsx          # News ticker strip
│   ├── TopBar.tsx          # Contact + social bar
│   ├── Navbar.tsx          # Sticky nav with dropdowns
│   ├── Hero.tsx            # Hero section with float cards
│   ├── AccredBar.tsx       # Accreditation badges bar
│   ├── About.tsx           # About SSIM section
│   ├── Programs.tsx        # Academic programs cards
│   ├── CampusLife.tsx      # Campus gallery grid
│   ├── Scholarship.tsx     # Scholarship tables
│   ├── StatsBanner.tsx     # Stats numbers banner
│   ├── Placements.tsx      # Placement stats + recruiter scroll
│   ├── WhySSIM.tsx         # Why choose SSIM grid
│   ├── Faculty.tsx         # Faculty cards
│   ├── Testimonials.tsx    # Student testimonials
│   ├── CTASection.tsx      # Call-to-action section
│   └── Footer.tsx          # Footer with links
├── next.config.js
├── tailwind.config.js
├── postcss.config.js
├── tsconfig.json
└── package.json
```

## Design Faithfulness

- All colors preserved via Tailwind theme extension (`navy`, `sky`, `blue`, `red`, `light`, `gray`, `border`)
- Same Google Fonts: **Playfair Display** + **DM Sans**
- All animations: ticker scroll, recruiter logo scroll
- All hover effects: nav underline, dropdown menus, card lifts, image zoom
- Responsive breakpoints matching original (hidden nav on mobile, single column on small screens)
- All Unsplash images and SSIM logo retained
- `next/image` used throughout for optimized image loading
